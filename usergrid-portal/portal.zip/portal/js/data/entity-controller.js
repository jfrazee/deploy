/**
 Licensed to the Apache Software Foundation (ASF) under one
 or more contributor license agreements.  See the NOTICE file
 distributed with this work for additional information
 regarding copyright ownership.  The ASF licenses this file
 to you under the Apache License, Version 2.0 (the
 "License"); you may not use this file except in compliance
 with the License.  You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing,
 software distributed under the License is distributed on an
 "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 KIND, either express or implied.  See the License for the
 specific language governing permissions and limitations
 under the License.
 */
'use strict';

AppServices.Controllers.controller('EntityCtrl', ['ug', '$scope', '$rootScope', '$location',
  function (ug, $scope, $rootScope, $location) {

    if (!$rootScope.selectedEntity) {
      $location.path('/data');
      return;
    }

    $scope.entityUUID  = $rootScope.selectedEntity.get('uuid');
    $scope.entityType  = $rootScope.selectedEntity.get('type');
    var tempjson  = $rootScope.selectedEntity.get();

    //rip out the system elements.  Stringify first because we don't want to rip them out of the actual object
    var queryBody = JSON.stringify(tempjson, null, 2);
    queryBody = JSON.parse(queryBody);
    delete queryBody.metadata;
    delete queryBody.uuid;
    delete queryBody.created;
    delete queryBody.modified;
    delete queryBody.type;

    $scope.queryBody = JSON.stringify(queryBody, null, 2);

    $scope.validateJson = function() {
      var queryBody = $scope.queryBody;

      try {
        queryBody = JSON.parse(queryBody);
      } catch (e) {
        $rootScope.$broadcast('alert', 'error', 'JSON is not valid');
        return false;
      }

      queryBody = JSON.stringify(queryBody,null,2);

      $rootScope.$broadcast('alert','success', 'JSON is valid');

      $scope.queryBody = queryBody;
      return true;

    }

    $scope.saveEntity = function(){
      if (!$scope.validateJson()) {
        return false;
      }
      var queryBody = $scope.queryBody;
      queryBody = JSON.parse(queryBody);
      $rootScope.selectedEntity.set(); //clears out all entities
      $rootScope.selectedEntity.set(queryBody);
      $rootScope.selectedEntity.set('type', $scope.entityType);
      $rootScope.selectedEntity.set('uuid', $scope.entityUUID);
      $rootScope.selectedEntity.save(function(err, data){
        if (err) {
          $rootScope.$broadcast('alert', 'error', 'error: ' + data.error_description);
        } else {
          $rootScope.$broadcast('alert', 'success', 'entity saved');
        }

      });
    }





  }]);