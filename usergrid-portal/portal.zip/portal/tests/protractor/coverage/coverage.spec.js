'use strict';
var util = require('../util');
describe('Output the code coverage objects', function () {
    it('should output the coverage object.',function(){
      util.getCoverage();
    });
});
